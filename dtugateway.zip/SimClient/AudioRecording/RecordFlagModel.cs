﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AudioRecording
{
    public class RecordFlagModel
    {
        public bool Flag { get; set; }
        public string RecprdFileName { get; set; }
        public string RecordFileFullPath { get; set; }
    }
}
