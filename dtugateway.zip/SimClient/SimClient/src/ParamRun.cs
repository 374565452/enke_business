﻿using DTU.GateWay.Protocol.WaterMessageClass;

namespace SimClient.src
{
    public class ParamRun
    {
        public static RTUParam_20 RTUParam_20;
        public static RTUParam_21 RTUParam_21;
        public static RTUParam_22 RTUParam_22;
        public static RTUParam_23 RTUParam_23;
        public static RTUParam_24 RTUParam_24;
        public static RTUParam_25 RTUParam_25;
        public static RTUParam_26 RTUParam_26;
        public static RTUParam_27 RTUParam_27;
        public static RTUParam_28 RTUParam_28;
        public static RTUParam_29 RTUParam_29;
        public static RTUParam_2A RTUParam_2A;
        public static RTUParam_2B RTUParam_2B;
        public static RTUParam_2C RTUParam_2C;
        public static RTUParam_2D RTUParam_2D;
        public static RTUParam_2E RTUParam_2E;
        public static RTUParam_2F RTUParam_2F;
        public static RTUParam_30 RTUParam_30;
        public static RTUParam_31 RTUParam_31;
        public static RTUParam_32 RTUParam_32;
        public static RTUParam_33 RTUParam_33;
        public static RTUParam_34 RTUParam_34;
        public static RTUParam_35 RTUParam_35;
        public static RTUParam_36 RTUParam_36;
        public static RTUParam_37 RTUParam_37;
        public static RTUParam_38 RTUParam_38;
        public static RTUParam_39 RTUParam_39;
        public static RTUParam_3A RTUParam_3A;
        public static RTUParam_3B RTUParam_3B;
        public static RTUParam_3C RTUParam_3C;
        public static RTUParam_3D RTUParam_3D;
        public static RTUParam_3E RTUParam_3E;
        public static RTUParam_3F RTUParam_3F;
        public static RTUParam_40 RTUParam_40;
        public static RTUParam_41 RTUParam_41;
    }
}
