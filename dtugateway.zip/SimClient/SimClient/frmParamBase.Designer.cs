﻿namespace SimClient
{
    partial class frmParamBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAdd1_B = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboChannelType1_B = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAdd1_M = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboChannelType1_M = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCenterStation1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtAdd2_B = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cboChannelType2_B = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAdd2_M = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cboChannelType2_M = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCenterStation2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtAdd3_B = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cboChannelType3_B = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAdd3_M = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cboChannelType3_M = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCenterStation3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtAdd4_B = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cboChannelType4_B = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtAdd4_M = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cboChannelType4_M = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtCenterStation4 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtRemoteStation = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cboWorkType = new System.Windows.Forms.ComboBox();
            this.cboSimNoType = new System.Windows.Forms.ComboBox();
            this.txtSimNo = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.btnSelIdenCollection = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblCount2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtAdd1_B);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cboChannelType1_B);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtAdd1_M);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cboChannelType1_M);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCenterStation1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(560, 67);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "中心站1";
            // 
            // txtAdd1_B
            // 
            this.txtAdd1_B.Location = new System.Drawing.Point(370, 39);
            this.txtAdd1_B.Name = "txtAdd1_B";
            this.txtAdd1_B.Size = new System.Drawing.Size(184, 21);
            this.txtAdd1_B.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(299, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "备用地址：";
            // 
            // cboChannelType1_B
            // 
            this.cboChannelType1_B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType1_B.FormattingEnabled = true;
            this.cboChannelType1_B.ItemHeight = 12;
            this.cboChannelType1_B.Location = new System.Drawing.Point(175, 39);
            this.cboChannelType1_B.Name = "cboChannelType1_B";
            this.cboChannelType1_B.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType1_B.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(107, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "备用类型：";
            // 
            // txtAdd1_M
            // 
            this.txtAdd1_M.Location = new System.Drawing.Point(370, 16);
            this.txtAdd1_M.Name = "txtAdd1_M";
            this.txtAdd1_M.Size = new System.Drawing.Size(184, 21);
            this.txtAdd1_M.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(311, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "主地址：";
            // 
            // cboChannelType1_M
            // 
            this.cboChannelType1_M.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType1_M.FormattingEnabled = true;
            this.cboChannelType1_M.ItemHeight = 12;
            this.cboChannelType1_M.Location = new System.Drawing.Point(175, 16);
            this.cboChannelType1_M.Name = "cboChannelType1_M";
            this.cboChannelType1_M.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType1_M.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "主类型：";
            // 
            // txtCenterStation1
            // 
            this.txtCenterStation1.Location = new System.Drawing.Point(53, 16);
            this.txtCenterStation1.Name = "txtCenterStation1";
            this.txtCenterStation1.Size = new System.Drawing.Size(50, 21);
            this.txtCenterStation1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "地址：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtAdd2_B);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cboChannelType2_B);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtAdd2_M);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cboChannelType2_M);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtCenterStation2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(12, 85);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(560, 67);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "中心站1";
            // 
            // txtAdd2_B
            // 
            this.txtAdd2_B.Location = new System.Drawing.Point(370, 39);
            this.txtAdd2_B.Name = "txtAdd2_B";
            this.txtAdd2_B.Size = new System.Drawing.Size(184, 21);
            this.txtAdd2_B.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(299, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "备用地址：";
            // 
            // cboChannelType2_B
            // 
            this.cboChannelType2_B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType2_B.FormattingEnabled = true;
            this.cboChannelType2_B.ItemHeight = 12;
            this.cboChannelType2_B.Location = new System.Drawing.Point(175, 39);
            this.cboChannelType2_B.Name = "cboChannelType2_B";
            this.cboChannelType2_B.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType2_B.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(107, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "备用类型：";
            // 
            // txtAdd2_M
            // 
            this.txtAdd2_M.Location = new System.Drawing.Point(370, 16);
            this.txtAdd2_M.Name = "txtAdd2_M";
            this.txtAdd2_M.Size = new System.Drawing.Size(184, 21);
            this.txtAdd2_M.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(311, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 4;
            this.label8.Text = "主地址：";
            // 
            // cboChannelType2_M
            // 
            this.cboChannelType2_M.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType2_M.FormattingEnabled = true;
            this.cboChannelType2_M.ItemHeight = 12;
            this.cboChannelType2_M.Location = new System.Drawing.Point(175, 16);
            this.cboChannelType2_M.Name = "cboChannelType2_M";
            this.cboChannelType2_M.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType2_M.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(119, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "主类型：";
            // 
            // txtCenterStation2
            // 
            this.txtCenterStation2.Location = new System.Drawing.Point(53, 16);
            this.txtCenterStation2.Name = "txtCenterStation2";
            this.txtCenterStation2.Size = new System.Drawing.Size(50, 21);
            this.txtCenterStation2.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "地址：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtAdd3_B);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.cboChannelType3_B);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txtAdd3_M);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.cboChannelType3_M);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txtCenterStation3);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Location = new System.Drawing.Point(12, 158);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(560, 67);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "中心站1";
            // 
            // txtAdd3_B
            // 
            this.txtAdd3_B.Location = new System.Drawing.Point(370, 39);
            this.txtAdd3_B.Name = "txtAdd3_B";
            this.txtAdd3_B.Size = new System.Drawing.Size(184, 21);
            this.txtAdd3_B.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(299, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 8;
            this.label11.Text = "备用地址：";
            // 
            // cboChannelType3_B
            // 
            this.cboChannelType3_B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType3_B.FormattingEnabled = true;
            this.cboChannelType3_B.ItemHeight = 12;
            this.cboChannelType3_B.Location = new System.Drawing.Point(175, 39);
            this.cboChannelType3_B.Name = "cboChannelType3_B";
            this.cboChannelType3_B.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType3_B.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(107, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 6;
            this.label12.Text = "备用类型：";
            // 
            // txtAdd3_M
            // 
            this.txtAdd3_M.Location = new System.Drawing.Point(370, 16);
            this.txtAdd3_M.Name = "txtAdd3_M";
            this.txtAdd3_M.Size = new System.Drawing.Size(184, 21);
            this.txtAdd3_M.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(311, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 4;
            this.label13.Text = "主地址：";
            // 
            // cboChannelType3_M
            // 
            this.cboChannelType3_M.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType3_M.FormattingEnabled = true;
            this.cboChannelType3_M.ItemHeight = 12;
            this.cboChannelType3_M.Location = new System.Drawing.Point(175, 16);
            this.cboChannelType3_M.Name = "cboChannelType3_M";
            this.cboChannelType3_M.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType3_M.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(119, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "主类型：";
            // 
            // txtCenterStation3
            // 
            this.txtCenterStation3.Location = new System.Drawing.Point(53, 16);
            this.txtCenterStation3.Name = "txtCenterStation3";
            this.txtCenterStation3.Size = new System.Drawing.Size(50, 21);
            this.txtCenterStation3.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "地址：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtAdd4_B);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.cboChannelType4_B);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.txtAdd4_M);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.cboChannelType4_M);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.txtCenterStation4);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Location = new System.Drawing.Point(12, 231);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(560, 67);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "中心站1";
            // 
            // txtAdd4_B
            // 
            this.txtAdd4_B.Location = new System.Drawing.Point(370, 39);
            this.txtAdd4_B.Name = "txtAdd4_B";
            this.txtAdd4_B.Size = new System.Drawing.Size(184, 21);
            this.txtAdd4_B.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(299, 42);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 8;
            this.label16.Text = "备用地址：";
            // 
            // cboChannelType4_B
            // 
            this.cboChannelType4_B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType4_B.FormattingEnabled = true;
            this.cboChannelType4_B.ItemHeight = 12;
            this.cboChannelType4_B.Location = new System.Drawing.Point(175, 39);
            this.cboChannelType4_B.Name = "cboChannelType4_B";
            this.cboChannelType4_B.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType4_B.TabIndex = 7;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(107, 43);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 6;
            this.label17.Text = "备用类型：";
            // 
            // txtAdd4_M
            // 
            this.txtAdd4_M.Location = new System.Drawing.Point(370, 16);
            this.txtAdd4_M.Name = "txtAdd4_M";
            this.txtAdd4_M.Size = new System.Drawing.Size(184, 21);
            this.txtAdd4_M.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(311, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 4;
            this.label18.Text = "主地址：";
            // 
            // cboChannelType4_M
            // 
            this.cboChannelType4_M.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChannelType4_M.FormattingEnabled = true;
            this.cboChannelType4_M.ItemHeight = 12;
            this.cboChannelType4_M.Location = new System.Drawing.Point(175, 16);
            this.cboChannelType4_M.Name = "cboChannelType4_M";
            this.cboChannelType4_M.Size = new System.Drawing.Size(115, 20);
            this.cboChannelType4_M.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(119, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "主类型：";
            // 
            // txtCenterStation4
            // 
            this.txtCenterStation4.Location = new System.Drawing.Point(53, 16);
            this.txtCenterStation4.Name = "txtCenterStation4";
            this.txtCenterStation4.Size = new System.Drawing.Size(50, 21);
            this.txtCenterStation4.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "地址：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(18, 313);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 12);
            this.label21.TabIndex = 4;
            this.label21.Text = "遥测站地址：";
            // 
            // txtRemoteStation
            // 
            this.txtRemoteStation.Location = new System.Drawing.Point(101, 309);
            this.txtRemoteStation.Name = "txtRemoteStation";
            this.txtRemoteStation.Size = new System.Drawing.Size(100, 21);
            this.txtRemoteStation.TabIndex = 5;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(212, 313);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 6;
            this.label22.Text = "密码：";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(259, 309);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(70, 21);
            this.txtPassword.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(335, 312);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 8;
            this.label23.Text = "工作方式：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(18, 346);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 12);
            this.label24.TabIndex = 9;
            this.label24.Text = "设备识别号：";
            // 
            // cboWorkType
            // 
            this.cboWorkType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboWorkType.FormattingEnabled = true;
            this.cboWorkType.Location = new System.Drawing.Point(406, 309);
            this.cboWorkType.Name = "cboWorkType";
            this.cboWorkType.Size = new System.Drawing.Size(160, 20);
            this.cboWorkType.TabIndex = 10;
            // 
            // cboSimNoType
            // 
            this.cboSimNoType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSimNoType.FormattingEnabled = true;
            this.cboSimNoType.Location = new System.Drawing.Point(158, 342);
            this.cboSimNoType.Name = "cboSimNoType";
            this.cboSimNoType.Size = new System.Drawing.Size(125, 20);
            this.cboSimNoType.TabIndex = 11;
            // 
            // txtSimNo
            // 
            this.txtSimNo.Location = new System.Drawing.Point(348, 342);
            this.txtSimNo.Name = "txtSimNo";
            this.txtSimNo.Size = new System.Drawing.Size(100, 21);
            this.txtSimNo.TabIndex = 12;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(99, 346);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 13;
            this.label25.Text = "卡类型：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(289, 346);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 14;
            this.label26.Text = "卡号码：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(18, 380);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(89, 12);
            this.label27.TabIndex = 15;
            this.label27.Text = "采集要素设置：";
            // 
            // btnSelIdenCollection
            // 
            this.btnSelIdenCollection.Location = new System.Drawing.Point(113, 375);
            this.btnSelIdenCollection.Name = "btnSelIdenCollection";
            this.btnSelIdenCollection.Size = new System.Drawing.Size(75, 23);
            this.btnSelIdenCollection.TabIndex = 16;
            this.btnSelIdenCollection.Text = "选择要素";
            this.btnSelIdenCollection.UseVisualStyleBackColor = true;
            this.btnSelIdenCollection.Click += new System.EventHandler(this.btnSelIdenCollection_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(113, 426);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(194, 426);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 18;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(194, 380);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(11, 12);
            this.lblCount.TabIndex = 19;
            this.lblCount.Text = "0";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(289, 431);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(47, 12);
            this.lblInfo.TabIndex = 20;
            this.lblInfo.Text = "lblInfo";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblCount2);
            this.groupBox5.Controls.Add(this.btnOK);
            this.groupBox5.Controls.Add(this.flowLayoutPanel1);
            this.groupBox5.Location = new System.Drawing.Point(372, 380);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(560, 437);
            this.groupBox5.TabIndex = 21;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "要素选择";
            this.groupBox5.Visible = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(8, 49);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(546, 375);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.MouseEnter += new System.EventHandler(this.flowLayoutPanel1_MouseEnter);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(8, 20);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "确定";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblCount2
            // 
            this.lblCount2.AutoSize = true;
            this.lblCount2.Location = new System.Drawing.Point(98, 25);
            this.lblCount2.Name = "lblCount2";
            this.lblCount2.Size = new System.Drawing.Size(11, 12);
            this.lblCount2.TabIndex = 20;
            this.lblCount2.Text = "0";
            // 
            // frmParamBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 461);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnSelIdenCollection);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtSimNo);
            this.Controls.Add(this.cboSimNoType);
            this.Controls.Add(this.cboWorkType);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtRemoteStation);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmParamBase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "基本参数配置";
            this.Load += new System.EventHandler(this.frmParamBase_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtAdd1_M;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboChannelType1_M;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCenterStation1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAdd1_B;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboChannelType1_B;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtAdd2_B;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboChannelType2_B;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAdd2_M;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboChannelType2_M;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCenterStation2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtAdd3_B;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cboChannelType3_B;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAdd3_M;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboChannelType3_M;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCenterStation3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtAdd4_B;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboChannelType4_B;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtAdd4_M;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cboChannelType4_M;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtCenterStation4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtRemoteStation;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cboWorkType;
        private System.Windows.Forms.ComboBox cboSimNoType;
        private System.Windows.Forms.TextBox txtSimNo;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnSelIdenCollection;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lblCount2;
    }
}