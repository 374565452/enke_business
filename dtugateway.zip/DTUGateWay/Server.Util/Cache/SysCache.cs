﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Util.Cache
{
    public class SysCache
    {
        public static bool ShowErrorLog
        {
            get;
            set;
        }

        public static bool ShowInfoLog
        {
            get;
            set;
        }

        public static bool RecordEevent
        {
            get;
            set;
        }
    }
}
